package techstore;

public class Adresse {
	private static String gouvernorat;
	private static int codePostal;
	public Adresse(String gouv,int codeP) {
		this.gouvernorat=gouv;
		this.codePostal=codeP;
	}
	public String gouvernorat(){
		return gouvernorat;
	}
	public void setGouvernorat(String gouv) {
		this.gouvernorat=gouv;
	}
	public int getCodePostal() {
		return codePostal;
	}
	public void setCodePostal(int codeP) {
		this.codePostal=codeP;
	}
	public String toString() {
		return "Adresse[gouvernorat:"+this.gouvernorat+" , CodePostal:"+this.codePostal+"]";
	}

	
}
