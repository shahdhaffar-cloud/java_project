package techstore;

public class Personne {
	private static String Cin;
	private static String Nom;
	private static String Prenom;
	private static Adresse adresse;
	public Personne(String CIN, String Nom, String Prenom, Adresse add) {
		this.Cin=CIN;
		this.Nom=Nom;
		this.Prenom=Prenom;
		this.adresse=add;
	}
	public Personne(String CIN, String Nom, String Prenom, String gouv,int codeP) {
		this.adresse.setGouvernorat(gouv);/*ou bien this.Adresse=new Adresse(goun,codeP)*/
		this.adresse.setCodePostal(codeP);
		this.Cin=CIN;
		this .Nom=Nom;
		this.Prenom=Prenom;	
	}
	public void setCin(String CIN) {
		this.Cin=CIN;
	}
	public String getCin() {
		return Cin;
	}
	public String getNom() {
		return Nom;
	}
	public String getPrenom() {
		return Prenom;
	}

	public void setNom(String Nom) {
		this.Nom=Nom;
	}
	public void setPrenom(String Prenom) {
		this.Prenom=Prenom;
	}
	public void setAdresse(Adresse add) {
		this.adresse=add;
	}
	public String toString() {
		return "CIN: "+this.Cin+", Nom: "+this.Nom+", Prenom: "+this.Prenom+", "+this.adresse.toString();
		
	}
	
	
}
