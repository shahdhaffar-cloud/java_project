package techstore;

import java.util.ArrayList;

public class Stock {

    private ArrayList<Element> articleList;


    public Stock() {
        articleList = new ArrayList<Element>();
    }

    public Stock(ArrayList<Element> liste) {
        articleList = new ArrayList<Element>(liste);
    }

    public Stock(ArrayList<String> noms,
                 ArrayList<Double> prix,
                 ArrayList<Long> quantites) {

        articleList = new ArrayList<Element>();

        if (noms.size() != prix.size() ||
            noms.size() != quantites.size()) {

            throw new IllegalArgumentException("Les listes doivent avoir la meme taille");
        }

        for (int i = 0; i < noms.size(); i++) {

            Element e = new Element(
                noms.get(i),
                prix.get(i),
                quantites.get(i)
            );

            articleList.add(e);
        }
    }

    public ArrayList<Element> getArticleList() {
        return articleList;
    }

    public int getArticleNb() {
        return articleList.size();
    }

    public void setArticleList(ArrayList<Element> liste) {
        articleList = liste;
    }

    public void ajouterArticle(Article article, long quantite) {

        Element e = trouverArticle(article.getReference());

        if (e != null) {
            e.incrementerQuantite(quantite);
        } else {
            Element nouveau = new Element(article, quantite);
            articleList.add(nouveau);
        }
    }

    public void ajouterArticle(String nom, double prix, long quantite) {

        Element e = new Element(nom, prix, quantite);

        articleList.add(e);
    }

    public Element trouverArticle(String reference) {

        for (Element e : articleList) {

            if (e.equals(reference)) {
                return e;
            }
        }

        return null;
    }

    public void modifierArticle(String reference,
                                String nouveauNom,
                                double nouveauPrix,
                                long nouvelleQuantite) {

        Element e = trouverArticle(reference);

        if (e != null) {
            e.modifier(nouveauNom, nouveauPrix, nouvelleQuantite);
        }
    }

    public void supprimerArticle(String reference) {

        Element e = trouverArticle(reference);

        if (e != null) {
            articleList.remove(e);
        }
    }

    public void incrementerQuantiteArticle(String reference, long quantite) {

        Element e = trouverArticle(reference);

        if (e != null) {
            e.incrementerQuantite(quantite);
        }
    }

    public void decrementerQuantiteArticle(String reference, long quantite) {

        Element e = trouverArticle(reference);

        if (e != null) {
            e.decrementerQuantite(quantite);
        }
    }

    public String toString() {

        String resultat = "";

        for (Element e : articleList) {
            resultat += e.toString() + "\n";
        }

        return resultat;
    }
}
