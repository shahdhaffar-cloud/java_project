package techstore;

public class Test {
	public void main() {
		System.out.println("Déclaration des adresses");
		Adresse a1 = new Adresse("Monastir", 5000);
		System.out.println(a1);
		Adresse a2 = new Adresse("Sousse", 4000);
		System.out.println(a2);
		Adresse a3 = new Adresse("Korba", 8070);
		System.out.println(a3);
		System.out.println("\nDéclaration de personne Const1");
		Personne p1 = new Personne("06582240","Shahd","Haffar",a3);
		System.out.println(p1);
		p1.setNom("Maryem");
		System.out.println("modification de nom\n"+p1);
		System.out.println("\nDéclaration de personne Const2");
		Personne p2 = new Personne("1468795","Maram","Hammadi","Monastir", 5000);
		System.out.println(p2);
		p2.setPrenom("Ahmed");
		System.out.println("modification de prenom\n"+p2);
		
	}

}
