package techstore;

import java.util.ArrayList;
import java.util.Scanner;

public class Test2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ArrayList<String> nomsInitiaux = new ArrayList<>();
        nomsInitiaux.add("Micro Casque 588 Filaire");

        ArrayList<Double> prixInitiaux = new ArrayList<>();
        prixInitiaux.add(150.0); 

        ArrayList<Long> quantitesInitiales = new ArrayList<>();
        quantitesInitiales.add(5L);

        Stock monStock = new Stock(nomsInitiaux, prixInitiaux, quantitesInitiales);

        int choix;
        do {
            System.out.println("\n========== GESTION DU STOCK TECHSTORE ==========");
            System.out.println("0 - Ajouter un article");
            System.out.println("1 - Augmenter la quantité d'un article");
            System.out.println("2 - Modifier un article");
            System.out.println("3 - Supprimer un article");
            System.out.println("4 - Consulter le stock");
            System.out.println("5 - Quitter");
            System.out.print("Entrez votre choix : ");
            
            choix = scanner.nextInt();
            scanner.nextLine(); 

            switch (choix) {
                case 0: 
                    System.out.print("Entrez le nom de l'article : ");
                    String nom = scanner.nextLine();
                    System.out.print("Entrez le prix de l'article : ");
                    double prix = scanner.nextDouble();
                    System.out.print("Entrez la quantité initiale : ");
                    long qte = scanner.nextLong();
                    scanner.nextLine();

                    monStock.ajouterArticle(nom, prix, qte);
                    System.out.println("Succès : L'article a été ajouté au stock.");
                    break;

                case 1: 
                    System.out.print("Entrez la référence de l'article à incrémenter : ");
                    String refInc = scanner.nextLine();
                    System.out.print("Entrez la quantité à ajouter : ");
                    long qteAjout = scanner.nextLong();
                    scanner.nextLine();

                    Element elInc = monStock.trouverArticle(refInc);
                    if (elInc != null) {
                        monStock.incrementerQuantiteArticle(refInc, qteAjout);
                        System.out.println("Succès : Quantité augmentée avec succès.");
                    } else {
                        System.out.println("Erreur : Aucun article ne correspond à cette référence.");
                    }
                    break;

                case 2: 
                    System.out.print("Entrez la référence de l'article à modifier : ");
                    String refModif = scanner.nextLine();
                    
                    Element elModif = monStock.trouverArticle(refModif);
                    if (elModif != null) {
                        System.out.print("Entrez le nouveau nom : ");
                        String nouvNom = scanner.nextLine();
                        System.out.print("Entrez le nouveau prix : ");
                        double nouvPrix = scanner.nextDouble();
                        System.out.print("Entrez la nouvelle quantité : ");
                        long nouvQte = scanner.nextLong();
                        scanner.nextLine();

                        monStock.modifierArticle(refModif, nouvNom, nouvPrix, nouvQte);
                        System.out.println("Succès : L'article a été modifié avec succès.");
                    } else {
                        System.out.println("Erreur : Article introuvable avec cette référence.");
                    }
                    break;

                case 3: 
                    System.out.print("Entrez la référence de l'article à supprimer : ");
                    String refSupp = scanner.nextLine();

                    Element elSupp = monStock.trouverArticle(refSupp);
                    if (elSupp != null) {
                        monStock.supprimerArticle(refSupp);
                        System.out.println("Succès : L'article a été supprimé du stock.");
                    } else {
                        System.out.println("Erreur : Impossible de supprimer, la référence est introuvable.");
                    }
                    break;

                case 4: 
                    System.out.println("\n--- État actuel du Stock ---");
                    if (monStock.getArticleNb() == 0) {
                        System.out.println("Le stock est vide.");
                    } else {
                        System.out.print(monStock.toString());
                    }
                    break;

                case 5: 
                    System.out.println("Fermeture du programme de gestion. Au revoir !");
                    break;

                default:
                    System.out.println("Erreur : Choix invalide, veuillez réessayer.");
            }
        } while (choix != 5);

        scanner.close();
    }
}
